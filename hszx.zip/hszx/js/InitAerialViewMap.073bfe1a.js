import{aR as e,i as a,o as r,j as i,s}from"./.store.9749408e.js";import{_ as n}from"./plugin-vue_export-helper.1b428a4d.js";function t(a,r){switch(function(){const e=window.cesiumViewer.imageryLayers._layers.filter((e=>e._layerIndex));if(!(e.length<=3)){let a=e.slice(3);for(const e of a)window.cesiumViewer.imageryLayers.remove(e)}}(),r){case"TianDiTu3DTerrain":!async function(e){const a="https://t{s}.tianditu.gov.cn/",r=["0","1","2","3","4","5","6","7"],i=new Cesium.UrlTemplateImageryProvider({url:a+"DataServer?T=img_w&x={x}&y={y}&l={z}&tk=6a382546ba19d8a0339eff37b3190cf1",subdomains:r,tilingScheme:new Cesium.WebMercatorTilingScheme,maximumLevel:18});e.imageryLayers.addImageryProvider(i);const s=new Cesium.UrlTemplateImageryProvider({url:a+"DataServer?T=ibo_w&x={x}&y={y}&l={z}&tk=6a382546ba19d8a0339eff37b3190cf1",subdomains:r,tilingScheme:new Cesium.WebMercatorTilingScheme,maximumLevel:10});e.imageryLayers.addImageryProvider(s);const n=new Cesium.WebMapTileServiceImageryProvider({url:a+"cia_w/wmts?tk=6a382546ba19d8a0339eff37b3190cf1",subdomains:r,layer:"cia",style:"default",tileMatrixSetID:"w",format:"tiles",maximumLevel:18});e.imageryLayers.addImageryProvider(n),e.terrainProvider=await Cesium.createWorldTerrainAsync({requestWaterMask:!0,requestVertexNormals:!0})}(a);break;case"Gaode2DImage":!function(a){a.imageryLayers.addImageryProvider(new e({style:"img",crs:"WGS84"})),a.imageryLayers.addImageryProvider(new e({style:"cva",crs:"WGS84"}))}(a);break;case"GaoDe2DShp":!function(a){a.imageryLayers.addImageryProvider(new e({style:"elec",crs:"WGS84"})),a.imageryLayers.addImageryProvider(new e({style:"cva",crs:"WGS84"}))}(a);break;case"TianDiTu2DShp":!function(e){const a="https://t{s}.tianditu.gov.cn/",r=["0","1","2","3","4","5","6","7"];let i=new Cesium.UrlTemplateImageryProvider({subdomains:r,url:a+"DataServer?T=vec_w&x={x}&y={y}&l={z}&tk=6a382546ba19d8a0339eff37b3190cf1",tilingScheme:new Cesium.WebMercatorTilingScheme,maximumLevel:18});e.imageryLayers.addImageryProvider(i);const s=new Cesium.WebMapTileServiceImageryProvider({url:a+"cia_w/wmts?tk=6a382546ba19d8a0339eff37b3190cf1",subdomains:r,layer:"cia",style:"default",tileMatrixSetID:"w",format:"tiles",maximumLevel:18});e.imageryLayers.addImageryProvider(s)}(a)}}const o={class:"aerial_view",id:"aerial_view"},m=n(a({__name:"InitAerialViewMap",setup:e=>(r((()=>{var e;e="aerial_view",Cesium.Ion.defaultAccessToken="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJlZWRlNGI2NC0wYTNhLTQ4MWEtYjBmYi0zMjcwYWQyNDUwYmYiLCJpZCI6MjU0NTQ1LCJpYXQiOjE3MzEzNzQ3NjJ9.FlGJgVvGx4TMxL97k-CTrpZJPVFlu-8CdkfnCycLoVI",window.aerialView=new Cesium.Viewer(e,{animation:!1,
// * 左下角圆盘 速度控制器
geocoder:!1,
// * 右上角搜索框
shouldAnimate:!0,
// * 当动画控件出现，用来控制是否通过旋转控件，旋转场景
baseLayerPicker:!1,
// * 右上角图层选择器
navigationInstructionsInitiallyVisible:!0,
// * 是否展开帮助
fullscreenButton:!1,
// * 右下角全屏按钮
vrButton:!1,
// * 右下角vr按钮
homeButton:!1,
// * 右上角地图恢复到初始页面按钮
selectionIndicator:!0,
// * 点击后地图上显示的选择控件
infoBox:!1,
// * 右上角鼠标点击后信息展示框
sceneModePicker:!1,
// * 右上角2D和3D之间的切换
timeline:!1,
// * 页面下方的时间条
navigationHelpButton:!1,
// * 右上角帮助按钮
scene3DOnly:!0,
// * 如果设置为true，则所有几何图形以3D模式绘制以节约GPU资源
useDefaultRenderLoop:!0,
// * 控制渲染循环
showRenderLoopErrors:!1,
// * HTML面板中显示错误信息
useBrowserRecommendedResolution:!0,
// * 如果为true，则以浏览器建议的分辨率渲染并忽略window.devicePixelRatio
automaticallyTrackDataSourceClocks:!0,
// * 自动追踪最近添加的数据源的时钟设置
orderIndependentTranslucency:!0,
// * 如果为true并且配置支持它，则使用顺序无关的半透明性
shadows:!1,
// * 阴影效果
projectionPicker:!1,
// * 透视投影和正投影之间切换
requestRenderMode:!0}),window.aerialView.cesiumWidget.creditContainer.style.display="none",window.aerialView.scene.screenSpaceCameraController.zoomEventTypes=[Cesium.CameraEventType.WHEEL,Cesium.CameraEventType.PINCH],window.aerialView.scene.screenSpaceCameraController.tiltEventTypes=[Cesium.CameraEventType.PINCH,Cesium.CameraEventType.LEFT_DRAG],window.aerialView.scene.screenSpaceCameraController.enableRotate=!1,t(window.aerialView,"TianDiTu3DTerrain");const a="113.0231382461631,23.135108621871483,1500".split(",");window.aerialView.camera.setView({destination:Cesium.Cartesian3.fromDegrees(Number(a[0]),Number(a[1]),Number(a[2]))})})),(e,a)=>(i(),s("div",o)))}),[["__scopeId","data-v-4edf64c9"]]);export{m as I,t as s};
