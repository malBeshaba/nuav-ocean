var t=Object.defineProperty,i=(i,e,a)=>(((i,e,a)=>{e in i?t(i,e,{enumerable:!0,configurable:!0,writable:!0,value:a}):i[e]=a})(i,"symbol"!=typeof e?e+"":e,a),a);import{s as e,R as a,h as o}from"../assets/index-d72fe1d3.js";import{q as n}from"./.store.9749408e.js";function r(t,i){const e=function(t){const i=[].concat(...t),e=[],a=[];for(let c=0;c<i.length;c+=3)e.push(i[c]),a.push(i[c+1]);e.sort(((t,i)=>t-i)),a.sort(((t,i)=>t-i));const o=e[e.length-1],n=e[0],r=a[a.length-1],s=a[0];return[n,r,n,s,o,s,o,r]}(i);var a;(a=e)[0],a[4],a[1],a[3],t.camera.flyTo({destination:Cesium.Rectangle.fromDegrees(e[0]-.001,e[3]-5e-4,e[4]+.001,e[1]+5e-4),orientation:{heading:Cesium.Math.toRadians(0),
// 方位角
pitch:Cesium.Math.toRadians(-90),
// 倾斜角度
roll:0}})}function s(t,i,e,a){let o=new Cesium.Cartesian2(i,e),n=t.scene.globe.pick(t.camera.getPickRay(o),t.scene),r=new Cesium.Cartesian3(n.x,n.y,n.z),s=Cesium.Cartographic.fromCartesian(r);return[Cesium.Math.toDegrees(s.longitude),Cesium.Math.toDegrees(s.latitude),a]}function c(t,i){t.camera.changed.addEventListener((function(){const a=t.camera.position,o=t.camera.heading,n=t.camera.pitch,r=t.camera.roll;if("cesiumViewer"===i){const t={cameraPosition:a,cameraHeading:o,cameraPitch:n,cameraRoll:r};e.commit("SET_MAP_CAMERA_ATTRIBUTE",t)}}))}class u{constructor(t){i(this,"position"),
//viewHeading:Number;
//viewPitch:Number;
//viewRoll:Number;
i(this,"fov"),i(this,"near"),i(this,"far"),i(this,"aspectRatio"),i(this,"frustumPrimitive"),i(this,"outlinePrimitive"),i(this,"orientation"),this.position=t.position,this.orientation=t.orientation,this.fov=t.fov||30,this.near=t.near,this.far=t.far||100,this.aspectRatio=t.aspectRatio,this.add()}
// 更新视锥体的姿态
update(t,i){this.position=t,this.orientation=i,this.add()}
// 创建视锥体和轮廓线
add(){this.clear(),this.addFrustum(),this.addOutline()}
// 清除视锥体和轮廓线
clear(){this.clearFrustum(),this.clearOutline()}
// 清除视锥体
clearFrustum(){this.frustumPrimitive&&(window.cesiumViewer.scene.primitives.remove(this.frustumPrimitive),this.frustumPrimitive=null)}
// 清除轮廓线
clearOutline(){this.outlinePrimitive&&(window.cesiumViewer.scene.primitives.remove(this.outlinePrimitive),this.outlinePrimitive=null)}
// 创建视锥体
addFrustum(){let t=new Cesium.PerspectiveFrustum({
// 查看的视场角，绕Z轴旋转，以弧度方式输入
// fov: Cesium.Math.PI_OVER_THREE,
fov:Cesium.Math.toRadians(this.fov),
// 视锥体的宽度/高度
aspectRatio:this.aspectRatio,
// 近面距视点的距离
near:this.near,
// 远面距视点的距离
far:this.far}),i=new Cesium.FrustumGeometry({frustum:t,origin:this.position,orientation:this.orientation,vertexFormat:Cesium.VertexFormat.POSITION_ONLY}),e=new Cesium.GeometryInstance({geometry:i,attributes:{color:Cesium.ColorGeometryInstanceAttribute.fromColor(new Cesium.Color(0,1,0,.5))},id:"frustumPrimitive"}),a=new Cesium.Primitive({geometryInstances:e,appearance:new Cesium.PerInstanceColorAppearance({closed:!0,flat:!0}),asynchronous:!1});this.frustumPrimitive=window.cesiumViewer.scene.primitives.add(a,0)}
// 创建轮廓线
addOutline(){let t=new Cesium.PerspectiveFrustum({
// 查看的视场角度，绕Z轴旋转，以弧度方式输入
// The angle of the field of view (FOV), in radians.
// This angle will be used as the horizontal FOV if the width is greater than the height, otherwise it will be the vertical FOV.
fov:Cesium.Math.toRadians(this.fov),
// 视锥体的宽度/高度
aspectRatio:this.aspectRatio,
// 近面距视点的距离
near:this.near,
// 远面距视点的距离
far:this.far}),i=new Cesium.FrustumOutlineGeometry({frustum:t,origin:this.position,orientation:this.orientation}),e=new Cesium.GeometryInstance({geometry:i,attributes:{color:Cesium.ColorGeometryInstanceAttribute.fromColor(new Cesium.Color(1,1,0,1))},id:"outlinePrimitive"}),a=new Cesium.Primitive({geometryInstances:e,appearance:new Cesium.PerInstanceColorAppearance({closed:!0,flat:!0}),asynchronous:!1});this.outlinePrimitive=window.cesiumViewer.scene.primitives.add(a,1)}}function m(t,i,e,n,r){t.entities.values.forEach((t=>{t.id.includes("wayLineDrawingFlightController")&&a(window.cesiumViewer,t.id)}));let s=t.camera.heading,c=Cesium.Math.toDegrees(s);360!==c&&(n+=c);let u=o;const m=new Cesium.HeadingPitchRoll(Cesium.Math.toRadians(450-n),0,0),l=Cesium.Transforms.headingPitchRollQuaternion(Cesium.Cartesian3.fromDegrees(e[0],e[1],e[2]),m);t.entities.add({id:i,position:Cesium.Cartesian3.fromDegrees(e[0],e[1],e[2]),orientation:l,model:{uri:u,minimumPixelSize:70,maximumScale:2e4}}),window.aerialView.camera.setView({
// destination:Cesium.Cartesian3.fromDegrees(pointLocation[0], pointLocation[1], pointLocation[2]),
orientation:{heading:Cesium.Math.toRadians(450-n),
// pitch: window.cesiumViewer.camera.pitch,
// roll: window.cesiumViewer.camera.roll
pitch:Cesium.Math.toRadians(270),
// roll:Cesium.Math.toRadians(90),
roll:0}})}function l(t,i,e){let a=window.aerialView.scene.camera.positionCartographic,o=[Cesium.Math.toDegrees(a.longitude),Cesium.Math.toDegrees(a.latitude),a.height],n=t.camera.heading,r=Cesium.Math.toDegrees(n);360!==r&&(i+=r);const s=new Cesium.HeadingPitchRoll(Cesium.Math.toRadians(450-i),270,Cesium.Math.toRadians(180)),c=Cesium.Transforms.headingPitchRollQuaternion(Cesium.Cartesian3.fromDegrees(o[0],o[1],o[2]),s);let m=Cesium.Cartesian3.fromDegrees(o[0],o[1],o[2]);return new u({position:m,orientation:c,fov:90,near:1,far:o[2],aspectRatio:800/1080})}const h="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";function d(t,i,a,o=null){null==e.state.EditingWayLine.WayLineList&&(e.state.EditingWayLine.WayLineList=[]);let r=e.state.EditingWayLine.WayLineList.length;const s=n({Point:{coordinates:t},index:r,executeHeight:i,waypointSpeed:a,waypointTurnParam:{waypointTurnMode:"toPointAndStopWithDiscontinuityCurvature",waypointTurnDampingDist:.2},useGlobalHeadingParam:1,useGlobalHeight:1,useGlobalSpeed:1,useGlobalTurnParam:1,useStraightLine:1}),c=n({actionGroupId:r+1,actionGroupStartIndex:r,actionGroupEndIndex:r,actionGroupMode:"sequence",
//下面是动作的触发器
actionTrigger:{actionTriggerType:"reachPoint"},action:[]});if(null!=o&&(s.Point.coordinates=o.Point.coordinates,s.executeHeight=o.executeHeight,s.waypointSpeed=o.waypointSpeed,s.waypointTurnParam=o.waypointTurnParam,o.actionGroup&&(c.actionGroupId=o.actionGroup[0].actionGroupId,c.action=o.actionGroup[0].action,c.action)))for(let e=0;e<c.action.length;e++)"startRecord"==c.action[e].actionActuatorFunc?c.action[e].actionName="StartRecord":"stopRecord"==c.action[e].actionActuatorFunc?c.action[e].actionName="StopRecord":""==c.action[e].actionActuatorFunc?c.action[e].actionName="StopEqualIntervalTakePhoto":"hover"==c.action[e].actionActuatorFunc?c.action[e].actionName="Hover":"rotateYaw"==c.action[e].actionActuatorFunc?c.action[e].actionName="DroneYaw":"gimbalRotate"==c.action[e].actionActuatorFunc?c.action[e].actionActuatorFuncParam.gimbalYawRotateEnable?c.action[e].actionName="GimbalYaw":c.action[e].actionName="GimbalPitch":"takePhoto"==c.action[e].actionActuatorFunc?c.action[e].actionActuatorFuncParam.hoverTime?c.action[e].actionName="StartEqualDistanceIntervalTakePhoto":c.action[e].actionName="TakePhoto":"zoom"==c.action[e].actionActuatorFunc?c.action[e].actionName="Zoom":"customDirName"==c.action[e].actionActuatorFunc?c.action[e].actionName="NewFolder":c.action[e].actionActuatorFunc;t.split(",");let u="";for(let e=0;e<14;e++)u+=h[Math.floor(62*Math.random())];const m=n({WayPointParam:s,WayPointActionList:c,WayPointID:u});null!=e.state.EditingWayLine.FocusWayPoint&&0!=r&&e.commit("UPDATE_WAYPOINT_INFO"),e.state.EditingWayLine.FocusWayPoint=m,e.state.EditingWayLine.WayLineList.push(m)}function p(t,i,a,o){null==e.state.EditingWayLine.WayLineList&&(e.state.EditingWayLine.WayLineList=[]);let r=o;const s=n({Point:{coordinates:t},index:r,executeHeight:i,waypointSpeed:a,waypointTurnParam:{waypointTurnMode:"toPointAndStopWithDiscontinuityCurvature",waypointTurnDampingDist:.2},useGlobalHeadingParam:1,useGlobalHeight:1,useGlobalSpeed:1,useGlobalTurnParam:1,useStraightLine:1}),c=n({actionGroupId:r+1,actionGroupStartIndex:r,actionGroupEndIndex:r,actionGroupMode:"sequence",
//下面是动作的触发器
actionTrigger:{actionTriggerType:"reachPoint"},action:[]});let u="";for(let e=0;e<14;e++)u+=h[Math.floor(62*Math.random())];const m=n({WayPointParam:s,WayPointActionList:c,WayPointID:u});e.commit("UPDATE_WAYPOINT_INFO"),e.state.EditingWayLine.FocusWayPoint=m,e.commit("INSERT_WAYPOINT_WITH_RANDOM_INDEX",m)}function g(t){return new Promise((i=>setTimeout(i,t)))}async function P(t){for(let i=0;i<=t.length-1;i++)await g(500),d(t[i].Point.coordinates,t[i].executeHeight,t[i].waypointSpeed,t[i])}export{r as C,m as D,d as I,s as S,p as a,P as b,l as c,c as w};
