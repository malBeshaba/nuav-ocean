import{aT as o}from"./.store.08cd4578.js";const s=o();export{s as b};
