import{_ as e}from"./plugin-vue_export-helper.1b428a4d.js";import{aS as t,j as a,s as n,v as i,C as o,x as s,y as r,O as l,a2 as m,a3 as d,a0 as c,a1 as u,B as h,D as p,i as w,o as y,H as N,aa as P,ab as I,P as g,N as f,k as D,a5 as A}from"./.store.08cd4578.js";import{s as L}from"../assets/index-c168e898.js";function v(e,a){switch(function(){const e=window.cesiumViewer.imageryLayers._layers.filter((e=>e._layerIndex));if(!(e.length<=3)){let t=e.slice(3);for(const e of t)window.cesiumViewer.imageryLayers.remove(e)}}(),a){case"TianDiTu3DTerrain":!async function(e){const t="https://t{s}.tianditu.gov.cn/",a=["0","1","2","3","4","5","6","7"],n=new Cesium.UrlTemplateImageryProvider({url:t+"DataServer?T=img_w&x={x}&y={y}&l={z}&tk=6a382546ba19d8a0339eff37b3190cf1",subdomains:a,tilingScheme:new Cesium.WebMercatorTilingScheme,maximumLevel:18});e.imageryLayers.addImageryProvider(n);const i=new Cesium.UrlTemplateImageryProvider({url:t+"DataServer?T=ibo_w&x={x}&y={y}&l={z}&tk=6a382546ba19d8a0339eff37b3190cf1",subdomains:a,tilingScheme:new Cesium.WebMercatorTilingScheme,maximumLevel:10});e.imageryLayers.addImageryProvider(i);const o=new Cesium.WebMapTileServiceImageryProvider({url:t+"cia_w/wmts?tk=6a382546ba19d8a0339eff37b3190cf1",subdomains:a,layer:"cia",style:"default",tileMatrixSetID:"w",format:"tiles",maximumLevel:18});e.imageryLayers.addImageryProvider(o),e.terrainProvider=await Cesium.createWorldTerrainAsync({requestWaterMask:!0,requestVertexNormals:!0})}(e);break;case"Gaode2DImage":!function(e){e.imageryLayers.addImageryProvider(new t({style:"img",crs:"WGS84"})),e.imageryLayers.addImageryProvider(new t({style:"cva",crs:"WGS84"}))}(e);break;case"GaoDe2DShp":!function(e){e.imageryLayers.addImageryProvider(new t({style:"elec",crs:"WGS84"})),e.imageryLayers.addImageryProvider(new t({style:"cva",crs:"WGS84"}))}(e);break;case"TianDiTu2DShp":!function(e){const t="https://t{s}.tianditu.gov.cn/",a=["0","1","2","3","4","5","6","7"];let n=new Cesium.UrlTemplateImageryProvider({subdomains:a,url:t+"DataServer?T=vec_w&x={x}&y={y}&l={z}&tk=6a382546ba19d8a0339eff37b3190cf1",tilingScheme:new Cesium.WebMercatorTilingScheme,maximumLevel:18});e.imageryLayers.addImageryProvider(n);const i=new Cesium.WebMapTileServiceImageryProvider({url:t+"cia_w/wmts?tk=6a382546ba19d8a0339eff37b3190cf1",subdomains:a,layer:"cia",style:"default",tileMatrixSetID:"w",format:"tiles",maximumLevel:18});e.imageryLayers.addImageryProvider(i)}(e)}}const b={class:"record-component"},Y={class:"row"};const _=e({data:()=>({DroneYawNum:0,duration:"",ActionName:"startRecordParam"}),
//在组件初始化和参数发生改变的时候将值回传
mounted(){const e={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1,useGlobalPayloadLensIndex:1}};this.$emit("HandleReturnValues",this.fatherMsg,e)},watch:{DroneYawNum(e){const t={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1,useGlobalPayloadLensIndex:1}};this.$emit("HandleReturnValues",this.fatherMsg,t)}},props:["fatherMsg"],methods:{deleteItem(){this.$emit("deleteItem",this.fatherMsg)}}},[["render",function(e,t,s,r,l,m){return a(),n("div",b,[i("div",Y,[t[1]||(t[1]=o(" 动作：开始录像 ")),i("div",{class:"DeleteIcon",onClick:t[0]||(t[0]=(...e)=>m.deleteItem&&m.deleteItem(...e))})])])}]]),C={class:"record-component"},T={class:"row"};const V=e({data:()=>({DroneYawNum:0,duration:"",ActionName:"stopRecordParam"}),
//在组件初始化和参数发生改变的时候将值回传
mounted(){const e={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1}};this.$emit("HandleReturnValues",this.fatherMsg,e)},watch:{DroneYawNum(e){const t={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1}};this.$emit("HandleReturnValues",this.fatherMsg,t)}},props:["fatherMsg"],methods:{deleteItem(){this.$emit("deleteItem",this.fatherMsg)}}},[["render",function(e,t,s,r,l,m){return a(),n("div",C,[i("div",T,[t[1]||(t[1]=o(" 动作：停止记录 ")),i("div",{class:"DeleteIcon",onClick:t[0]||(t[0]=(...e)=>m.deleteItem&&m.deleteItem(...e))})])])}]]),M={class:"record-component"},W={class:"row"};const k=e({data:()=>({DroneYawNum:0,duration:"",ActionName:"rotateYawParam"}),
//在组件初始化和参数发生改变的时候将值回传
mounted(){const e={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
aircraftHeading:0,aircraftPathMode:"clockwise"}};this.$emit("HandleReturnValues",this.fatherMsg,e)},watch:{DroneYawNum(e){const t={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
aircraftHeading:e,aircraftPathMode:"clockwise"}};this.$emit("HandleReturnValues",this.fatherMsg,t)}},props:["fatherMsg"],methods:{deleteItem(){this.$emit("deleteItem",this.fatherMsg)}}},[["render",function(e,t,h,p,w,y){const N=d,P=c,I=u,g=m;return a(),n(l,null,[t[4]||(t[4]=i("br",null,null,-1)),i("div",M,[i("div",W,[t[3]||(t[3]=o(" 动作:飞行器偏航角 ")),i("div",{class:"DeleteIcon",onClick:t[0]||(t[0]=(...e)=>y.deleteItem&&y.deleteItem(...e))})]),s(g,{gutter:17},{default:r((()=>[s(P,{span:15},{default:r((()=>[s(N,{class:"DroneYawNum",modelValue:w.DroneYawNum,"onUpdate:modelValue":t[1]||(t[1]=e=>w.DroneYawNum=e),"show-tooltip":!1,step:.1,min:-180,max:180},null,8,["modelValue"])])),_:1}),s(P,{span:6},{default:r((()=>[s(I,{class:"DroneYawNumInput",size:"mini",modelValue:w.DroneYawNum,"onUpdate:modelValue":t[2]||(t[2]=e=>w.DroneYawNum=e)},null,8,["modelValue"])])),_:1})])),_:1})])],64)}]]),R={class:"record-component"},x={class:"row"};const S=e({data:()=>({DroneYawNum:0,duration:"",ActionName:"gimbalRotateParam"}),
//在组件初始化和参数发生改变的时候将值回传
mounted(){const e={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1,gimbalPitchRotateEnable:1,gimbalPitchRotateAngle:0,gimbalRotateTimeEnable:0}};this.$emit("HandleReturnValues",this.fatherMsg,e)},watch:{DroneYawNum(e){const t={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1,gimbalPitchRotateEnable:1,gimbalPitchRotateAngle:e,gimbalRotateTimeEnable:0}};this.$emit("HandleReturnValues",this.fatherMsg,t)}},props:["fatherMsg"],methods:{deleteItem(){this.$emit("deleteItem",this.fatherMsg)}}},[["render",function(e,t,h,p,w,y){const N=d,P=c,I=u,g=m;return a(),n(l,null,[t[4]||(t[4]=i("br",null,null,-1)),i("div",R,[i("div",x,[t[3]||(t[3]=o(" 动作：云台俯仰角 ")),i("div",{class:"DeleteIcon",onClick:t[0]||(t[0]=(...e)=>y.deleteItem&&y.deleteItem(...e))})]),s(g,{gutter:17},{default:r((()=>[s(P,{span:15},{default:r((()=>[s(N,{class:"DroneYawNum",modelValue:w.DroneYawNum,"onUpdate:modelValue":t[1]||(t[1]=e=>w.DroneYawNum=e),"show-tooltip":!1,step:.1,min:-90,max:90},null,8,["modelValue"])])),_:1}),s(P,{span:6},{default:r((()=>[s(I,{class:"DroneYawNumInput",size:"mini",modelValue:w.DroneYawNum,"onUpdate:modelValue":t[2]||(t[2]=e=>w.DroneYawNum=e)},null,8,["modelValue"])])),_:1})])),_:1})])],64)}]]),E={class:"record-component"},H={class:"row"};const $=e({data:()=>({DroneYawNum:0,duration:"",ActionName:"gimbalRotateParam"}),
//在组件初始化和参数发生改变的时候将值回传
mounted(){const e={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1,gimbalYawRotateEnable:1,gimbalYawRotateAngle:0,gimbalRotateTimeEnable:0}};this.$emit("HandleReturnValues",this.fatherMsg,e)},watch:{DroneYawNum(e){const t={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1,gimbalYawRotateEnable:1,gimbalYawRotateAngle:e,gimbalRotateTimeEnable:0}};this.$emit("HandleReturnValues",this.fatherMsg,t)}},props:["fatherMsg"],methods:{deleteItem(){this.$emit("deleteItem",this.fatherMsg)}}},[["render",function(e,t,h,p,w,y){const N=d,P=c,I=u,g=m;return a(),n(l,null,[t[4]||(t[4]=i("br",null,null,-1)),i("div",E,[i("div",H,[t[3]||(t[3]=o(" 动作：云台偏航角 ")),i("div",{class:"DeleteIcon",onClick:t[0]||(t[0]=(...e)=>y.deleteItem&&y.deleteItem(...e))})]),s(g,{gutter:17},{default:r((()=>[s(P,{span:15},{default:r((()=>[s(N,{class:"DroneYawNum",modelValue:w.DroneYawNum,"onUpdate:modelValue":t[1]||(t[1]=e=>w.DroneYawNum=e),"show-tooltip":!1,step:.1,min:-180,max:180},null,8,["modelValue"])])),_:1}),s(P,{span:6},{default:r((()=>[s(I,{class:"DroneYawNumInput",size:"mini",modelValue:w.DroneYawNum,"onUpdate:modelValue":t[2]||(t[2]=e=>w.DroneYawNum=e)},null,8,["modelValue"])])),_:1})])),_:1})])],64)}]]),z={class:"record-component"},O={class:"row"};const G=e({data:()=>({DroneYawNum:0,duration:"",ActionName:"hoverParam"}),
//在组件初始化和参数发生改变的时候将值回传
mounted(){const e={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
hoverTime:0}};this.$emit("HandleReturnValues",this.fatherMsg,e)},watch:{DroneYawNum(e){const t={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
hoverTime:e}};this.$emit("HandleReturnValues",this.fatherMsg,t)}},props:["fatherMsg"],methods:{deleteItem(){this.$emit("deleteItem",this.fatherMsg)},setDroneYawNum(e){this.DroneYawNum=e}}},[["render",function(e,t,d,p,w,y){const N=h,P=c,I=u,g=m;return a(),n(l,null,[t[11]||(t[11]=i("br",null,null,-1)),i("div",z,[i("div",O,[t[6]||(t[6]=o(" 动作：悬停 ")),i("div",{class:"DeleteIcon",onClick:t[0]||(t[0]=(...e)=>y.deleteItem&&y.deleteItem(...e))})]),s(g,{gutter:17},{default:r((()=>[s(P,{span:3},{default:r((()=>[s(N,{size:"medium",onClick:t[1]||(t[1]=e=>y.setDroneYawNum(5))},{default:r((()=>t[7]||(t[7]=[o("5s")]))),_:1})])),_:1}),s(P,{span:3},{default:r((()=>[s(N,{size:"medium",onClick:t[2]||(t[2]=e=>y.setDroneYawNum(10))},{default:r((()=>t[8]||(t[8]=[o("10s")]))),_:1})])),_:1}),s(P,{span:9},{default:r((()=>[s(I,{class:"HoverNumInput",size:"medium",modelValue:w.DroneYawNum,"onUpdate:modelValue":t[3]||(t[3]=e=>w.DroneYawNum=e)},null,8,["modelValue"])])),_:1}),s(P,{span:3},{default:r((()=>[s(N,{size:"medium",class:"WaitTime15",onClick:t[4]||(t[4]=e=>y.setDroneYawNum(15))},{default:r((()=>t[9]||(t[9]=[o("15s")]))),_:1})])),_:1}),s(P,{span:3},{default:r((()=>[s(N,{size:"medium",class:"WaitTime20",onClick:t[5]||(t[5]=e=>y.setDroneYawNum(20))},{default:r((()=>t[10]||(t[10]=[o("20s")]))),_:1})])),_:1})])),_:1})])],64)}]]),X={class:"record-component"},U={class:"row"};const j=e({data:()=>({DroneYawNum:0,FolderName:"",ActionName:"customDirNameParam"}),
//在组件初始化和参数发生改变的时候将值回传
mounted(){const e={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1,directoryName:"newfolder"+Math.floor(100*Math.random())+1}};this.$emit("HandleReturnValues",this.fatherMsg,e)},watch:{DroneYawNum(e){const t={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1,directoryName:e}};this.$emit("HandleReturnValues",this.fatherMsg,t)}},props:["fatherMsg"],methods:{deleteItem(){this.$emit("deleteItem",this.fatherMsg)}}},[["render",function(e,t,d,u,h,w){const y=c,N=p,P=m;return a(),n(l,null,[t[4]||(t[4]=i("br",null,null,-1)),i("div",X,[i("div",U,[t[2]||(t[2]=o(" 动作：新建文件夹 ")),i("div",{class:"DeleteIcon",onClick:t[0]||(t[0]=(...e)=>w.deleteItem&&w.deleteItem(...e))})]),s(P,{gutter:3},{default:r((()=>[s(y,{span:6,class:"InputName"},{default:r((()=>t[3]||(t[3]=[o("文件夹名：")]))),_:1}),s(y,{span:10},{default:r((()=>[s(N,{modelValue:h.FolderName,"onUpdate:modelValue":t[1]||(t[1]=e=>h.FolderName=e),placeholder:"请输入内容"},null,8,["modelValue"])])),_:1})])),_:1})])],64)}]]);const q={class:"aerial_view",id:"aerial_view"},Z=e(w({__name:"InitAerialViewMap",setup:e=>(y((()=>{var e;e="aerial_view",Cesium.Ion.defaultAccessToken="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJlZWRlNGI2NC0wYTNhLTQ4MWEtYjBmYi0zMjcwYWQyNDUwYmYiLCJpZCI6MjU0NTQ1LCJpYXQiOjE3MzEzNzQ3NjJ9.FlGJgVvGx4TMxL97k-CTrpZJPVFlu-8CdkfnCycLoVI",window.aerialView=new Cesium.Viewer(e,{animation:!1,
// * 左下角圆盘 速度控制器
geocoder:!1,
// * 右上角搜索框
shouldAnimate:!0,
// * 当动画控件出现，用来控制是否通过旋转控件，旋转场景
baseLayerPicker:!1,
// * 右上角图层选择器
navigationInstructionsInitiallyVisible:!0,
// * 是否展开帮助
fullscreenButton:!1,
// * 右下角全屏按钮
vrButton:!1,
// * 右下角vr按钮
homeButton:!1,
// * 右上角地图恢复到初始页面按钮
selectionIndicator:!0,
// * 点击后地图上显示的选择控件
infoBox:!1,
// * 右上角鼠标点击后信息展示框
sceneModePicker:!1,
// * 右上角2D和3D之间的切换
timeline:!1,
// * 页面下方的时间条
navigationHelpButton:!1,
// * 右上角帮助按钮
scene3DOnly:!0,
// * 如果设置为true，则所有几何图形以3D模式绘制以节约GPU资源
useDefaultRenderLoop:!0,
// * 控制渲染循环
showRenderLoopErrors:!1,
// * HTML面板中显示错误信息
useBrowserRecommendedResolution:!0,
// * 如果为true，则以浏览器建议的分辨率渲染并忽略window.devicePixelRatio
automaticallyTrackDataSourceClocks:!0,
// * 自动追踪最近添加的数据源的时钟设置
orderIndependentTranslucency:!0,
// * 如果为true并且配置支持它，则使用顺序无关的半透明性
shadows:!1,
// * 阴影效果
projectionPicker:!1,
// * 透视投影和正投影之间切换
requestRenderMode:!0}),window.aerialView.cesiumWidget.creditContainer.style.display="none",window.aerialView.scene.screenSpaceCameraController.zoomEventTypes=[Cesium.CameraEventType.WHEEL,Cesium.CameraEventType.PINCH],window.aerialView.scene.screenSpaceCameraController.tiltEventTypes=[Cesium.CameraEventType.PINCH,Cesium.CameraEventType.LEFT_DRAG],window.aerialView.scene.screenSpaceCameraController.enableRotate=!1,v(window.aerialView,"TianDiTu3DTerrain");const t="113.0231382461631,23.135108621871483,1500".split(",");window.aerialView.camera.setView({destination:Cesium.Cartesian3.fromDegrees(Number(t[0]),Number(t[1]),Number(t[2]))})})),(e,t)=>(a(),n("div",q)))}),[["__scopeId","data-v-4edf64c9"]]),J={class:"record-component"},F={class:"row"};const B=e({data:()=>({DroneYawNum:0,duration:"",ActionName:"StartEqualIntervalTakePhoto"}),
//在组件初始化和参数发生改变的时候将值回传
mounted(){const e={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
actionTriggerType:"multipleTiming",actionTriggerParam:10}};this.$emit("HandleReturnValues",this.fatherMsg,e)},watch:{DroneYawNum(e){const t={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
actionTriggerType:"multipleTiming",actionTriggerParam:e}};this.$emit("HandleReturnValues",this.fatherMsg,t)}},props:["fatherMsg"],methods:{deleteItem(){this.$emit("deleteItem",this.fatherMsg)},setDroneYawNum(e){this.DroneYawNum=e}}},[["render",function(e,t,d,p,w,y){const N=h,P=c,I=u,g=m;return a(),n(l,null,[t[11]||(t[11]=i("br",null,null,-1)),i("div",J,[i("div",F,[t[6]||(t[6]=o(" 动作：开始等时间间隔拍照 ")),i("div",{class:"DeleteIconOne",onClick:t[0]||(t[0]=(...e)=>y.deleteItem&&y.deleteItem(...e))})]),s(g,{gutter:17},{default:r((()=>[s(P,{span:3},{default:r((()=>[s(N,{size:"medium",onClick:t[1]||(t[1]=e=>y.setDroneYawNum(5))},{default:r((()=>t[7]||(t[7]=[o("5m")]))),_:1})])),_:1}),s(P,{span:3},{default:r((()=>[s(N,{size:"medium",onClick:t[2]||(t[2]=e=>y.setDroneYawNum(10))},{default:r((()=>t[8]||(t[8]=[o("10m")]))),_:1})])),_:1}),s(P,{span:9},{default:r((()=>[s(I,{class:"HoverNumInput",size:"medium",modelValue:w.DroneYawNum,"onUpdate:modelValue":t[3]||(t[3]=e=>w.DroneYawNum=e)},null,8,["modelValue"])])),_:1}),s(P,{span:3},{default:r((()=>[s(N,{size:"medium",class:"WaitTime15",onClick:t[4]||(t[4]=e=>y.setDroneYawNum(15))},{default:r((()=>t[9]||(t[9]=[o("15m")]))),_:1})])),_:1}),s(P,{span:3},{default:r((()=>[s(N,{size:"medium",class:"WaitTime20",onClick:t[5]||(t[5]=e=>y.setDroneYawNum(20))},{default:r((()=>t[10]||(t[10]=[o("20m")]))),_:1})])),_:1})])),_:1})])],64)}]]),Q={class:"record-component"},K={class:"row"};const ee=e({data:()=>({DroneYawNum:0,duration:"",ActionName:"StartEqualDistanceIntervalTakePhoto"}),
//在组件初始化和参数发生改变的时候将值回传
mounted(){const e={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
actionTriggerType:"multipleDistance",actionTriggerParam:10}};this.$emit("HandleReturnValues",this.fatherMsg,e)},watch:{DroneYawNum(e){const t={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
actionTriggerType:"multipleDistance",actionTriggerParam:e}};this.$emit("HandleReturnValues",this.fatherMsg,t)}},props:["fatherMsg"],methods:{deleteItem(){this.$emit("deleteItem",this.fatherMsg)},setDroneYawNum(e){this.DroneYawNum=e}}},[["render",function(e,t,d,p,w,y){const N=h,P=c,I=u,g=m;return a(),n(l,null,[t[11]||(t[11]=i("br",null,null,-1)),i("div",Q,[i("div",K,[t[6]||(t[6]=o(" 动作：开始等距离间隔拍照 ")),i("div",{class:"DeleteIconOne",onClick:t[0]||(t[0]=(...e)=>y.deleteItem&&y.deleteItem(...e))})]),s(g,{gutter:17},{default:r((()=>[s(P,{span:3},{default:r((()=>[s(N,{size:"medium",onClick:t[1]||(t[1]=e=>y.setDroneYawNum(5))},{default:r((()=>t[7]||(t[7]=[o("5s")]))),_:1})])),_:1}),s(P,{span:3},{default:r((()=>[s(N,{size:"medium",onClick:t[2]||(t[2]=e=>y.setDroneYawNum(10))},{default:r((()=>t[8]||(t[8]=[o("10s")]))),_:1})])),_:1}),s(P,{span:9},{default:r((()=>[s(I,{class:"HoverNumInput",size:"medium",modelValue:w.DroneYawNum,"onUpdate:modelValue":t[3]||(t[3]=e=>w.DroneYawNum=e)},null,8,["modelValue"])])),_:1}),s(P,{span:3},{default:r((()=>[s(N,{size:"medium",class:"WaitTime15",onClick:t[4]||(t[4]=e=>y.setDroneYawNum(15))},{default:r((()=>t[9]||(t[9]=[o("15s")]))),_:1})])),_:1}),s(P,{span:3},{default:r((()=>[s(N,{size:"medium",class:"WaitTime20",onClick:t[5]||(t[5]=e=>y.setDroneYawNum(20))},{default:r((()=>t[10]||(t[10]=[o("20s")]))),_:1})])),_:1})])),_:1})])],64)}]]),te={class:"record-component"},ae={class:"row"};const ne=e({data:()=>({DroneYawNum:500,duration:"",ActionName:"zoomParam"}),
//在组件初始化和参数发生改变的时候将值回传
mounted(){const e={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1,useGlobalPayloadLensIndex:500}};this.$emit("HandleReturnValues",this.fatherMsg,e)},watch:{DroneYawNum(e){const t={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1,useGlobalPayloadLensIndex:e}};this.$emit("HandleReturnValues",this.fatherMsg,t)}},props:["fatherMsg"],methods:{deleteItem(){this.$emit("deleteItem",this.fatherMsg)},setDroneYawNum(e){this.DroneYawNum=e}}},[["render",function(e,t,l,d,p,w){const y=h,N=c,P=u,I=m;return a(),n("div",te,[i("div",ae,[t[6]||(t[6]=o(" 动作：变焦 ")),i("div",{class:"DeleteIcon",onClick:t[0]||(t[0]=(...e)=>w.deleteItem&&w.deleteItem(...e))})]),s(I,{gutter:17},{default:r((()=>[s(N,{span:3},{default:r((()=>[s(y,{class:"WaitTime15",size:"medium",onClick:t[1]||(t[1]=e=>w.setDroneYawNum(300))},{default:r((()=>t[7]||(t[7]=[o("300m")]))),_:1})])),_:1}),s(N,{span:3},{default:r((()=>[s(y,{class:"WaitTime15",size:"medium",onClick:t[2]||(t[2]=e=>w.setDroneYawNum(400))},{default:r((()=>t[8]||(t[8]=[o("400m")]))),_:1})])),_:1}),s(N,{span:9},{default:r((()=>[s(P,{class:"HoverNumInputOne",size:"medium",modelValue:p.DroneYawNum,"onUpdate:modelValue":t[3]||(t[3]=e=>p.DroneYawNum=e)},null,8,["modelValue"])])),_:1}),s(N,{span:3},{default:r((()=>[s(y,{size:"medium",class:"WaitTime15",onClick:t[4]||(t[4]=e=>w.setDroneYawNum(600))},{default:r((()=>t[9]||(t[9]=[o("600m")]))),_:1})])),_:1}),s(N,{span:3},{default:r((()=>[s(y,{size:"medium",class:"WaitTime20",onClick:t[5]||(t[5]=e=>w.setDroneYawNum(700))},{default:r((()=>t[10]||(t[10]=[o("700m")]))),_:1})])),_:1})])),_:1})])}]]),ie={class:"record-component"},oe={class:"row"};const se=e({data:()=>({DroneYawNum:0,duration:"",ActionName:"takePhotoParam"}),
//在组件初始化和参数发生改变的时候将值回传
mounted(){const e={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1,useGlobalPayloadLensIndex:1}};this.$emit("HandleReturnValues",this.fatherMsg,e)},watch:{DroneYawNum(e){const t={ActionName:this.ActionName,ActionParam:{
//参数的多少是根据接口文档中编写的，有部分参数的设置的默认值，这是因为前端需要简洁没有流出太多的可供用户选择的参数
//因为在前面定义出现传值未定义的问题，懒得改了直接写在下面
payloadPositionIndex:1,useGlobalPayloadLensIndex:1}};this.$emit("HandleReturnValues",this.fatherMsg,t)}},props:["fatherMsg"],methods:{deleteItem(){this.$emit("deleteItem",this.fatherMsg)}}},[["render",function(e,t,s,r,l,m){return a(),n("div",ie,[i("div",oe,[t[1]||(t[1]=o(" 动作：拍照 ")),i("div",{class:"DeleteIcon",onClick:t[0]||(t[0]=(...e)=>m.deleteItem&&m.deleteItem(...e))})])])}]]),re={class:"record-component"},le={class:"row"};const me={class:"panel"},de={class:"top-section"},ce={key:0,class:"CountOfWaypointAction"},ue={key:1,class:"CountOfWaypointAction"},he={class:"WayPointActionList"},pe=["onClick","onMouseover"],we={class:"bottom-section"},ye={class:"content"};const Ne=e({name:"AddWayPointActionPanel",components:{InitAerialViewMap:Z,StopRecord:V,StartRecord:_,StartEqualIntervalTakePhoto:B,StartEqualDistanceIntervalTakePhoto:ee,StopEqualIntervalTakePhoto:e({data:()=>({DroneYawNum:0,duration:"",ActionName:"StopEqualIntervalTakePhoto"}),
//在组件初始化和参数发生改变的时候将值回传
mounted(){const e={ActionName:this.ActionName,ActionParam:{}};this.$emit("HandleReturnValues",this.fatherMsg,e)},watch:{DroneYawNum(e){const t={ActionName:this.ActionName,ActionParam:{}};this.$emit("HandleReturnValues",this.fatherMsg,t)}},props:["fatherMsg"],methods:{deleteItem(){this.$emit("deleteItem",this.fatherMsg)}}},[["render",function(e,t,s,r,l,m){return a(),n("div",re,[i("div",le,[t[1]||(t[1]=o(" 动作：结束间隔拍照 ")),i("div",{class:"DeleteIconOne",onClick:t[0]||(t[0]=(...e)=>m.deleteItem&&m.deleteItem(...e))})])])}]]),DroneYaw:k,GimbalYaw:$,GimbalPitch:S,Hover:G,NewFolder:j,Zoom:ne,TakePhoto:se},data:()=>({CurrentNum:0,
//下面这个StoreWayLineActionList存储着所有的待回传的该航线的动作
StoreWayLineActionList:{},
//其中的数据结构大致为下：
// [
//     这是航点一{
//   航点一的第一个动作：{
//   动作的名字：
//   动作的参数：{...}
//   }
// },
//     这是航点二{..},
//     这是航点三{..},
//     这是航点四{..},
//     ]
WayLineActionList:{},hoveredItem:null,selectedPoint:{number:null,pointId:"activate",pointX:0},historyWayLine:[],number:0,
// 初始数字值为0
showDropdown:!1,
// 控制下拉框显示/隐藏的标志
items:[
// 下拉框的选项列表,componentName:''
{id:1,text:"开始录像",componentName:"StartRecord"},{id:2,text:"停止录像",componentName:"StopRecord"},{id:3,text:"开始等时间间隔拍照",componentName:"StartEqualIntervalTakePhoto"},{id:4,text:"开始等距间隔拍照",componentName:"StartEqualDistanceIntervalTakePhoto"},{id:5,text:"结束间隔拍照",componentName:"StopEqualIntervalTakePhoto"},{id:6,text:"悬停",componentName:"Hover"},{id:7,text:"飞行器偏航角",componentName:"DroneYaw"},{id:8,text:"云台偏航角",componentName:"GimbalYaw"},{id:9,text:"云台俯仰角",componentName:"GimbalPitch"},{id:10,text:"拍照",componentName:"TakePhoto"},{id:11,text:"相机变焦",componentName:"Zoom"},{id:12,text:"创建文件夹",componentName:"NewFolder"}],displayedComponents:[]}),watch:{"$store.state.wayLinePointsDrawingActive"(e,t){this.selectedPoint.pointId=e.pointId,L.state.wayLinePointsDrawing.forEach(((t,a)=>{t.pointX.toFixed(12)===e.pointX.toFixed(12)&&(this.clearlist(a,this.selectedPoint.number),this.selectedPoint.number=a)}))},"$store.state.wayLinePointsDrawing":{handler(e,t){if(this.clearlist(),1===e.length){this.selectedPoint.pointId=e[0].pointId,this.selectedPoint.pointX=e[0].pointX,this.selectedPoint.number=0;const t={pointId:L.state.wayLinePointsDrawingActive.pointId,pointX:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointX,pointY:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointY,pointZ:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointZ};L.commit("SET_WAY_LINE_POINT_DRAWING_ACTIVE",t)}else{let t=!1;if(L.state.wayLinePointsDrawing.forEach(((e,a)=>{"before"!==e.addManner&&"after"!==e.addManner&&"move"!==e.addManner||(t=!0)})),t){let t=new Array(e.length).fill(!1);e.forEach(((e,a)=>{const n=e.pointX.toFixed(12);this.historyWayLine.forEach((e=>{const i=e.pointX.toFixed(12);n===i&&(t[a]=!0)}))})),t.forEach(((t,a)=>{t||(this.selectedPoint.pointId=e[a].pointId,this.selectedPoint.pointX=e[a].pointX,this.selectedPoint.number=a,this.clearlistforInsert(a))}));const a={pointId:L.state.wayLinePointsDrawingActive.pointId,pointX:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointX,pointY:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointY,pointZ:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointZ};L.commit("SET_WAY_LINE_POINT_DRAWING_ACTIVE",a),this.historyWayLine=JSON.parse(JSON.stringify(e))}else{this.selectedPoint.pointId=e[e.length-1].pointId,this.selectedPoint.pointX=e[e.length-1].pointX,this.selectedPoint.number=e.length-1,this.clearlist(e.length-1,e.length-2);const t={pointId:L.state.wayLinePointsDrawingActive.pointId,pointX:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointX,pointY:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointY,pointZ:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointZ};L.commit("SET_WAY_LINE_POINT_DRAWING_ACTIVE",t),this.historyWayLine=JSON.parse(JSON.stringify(e))}}},deep:!0}},methods:{
//切换航点，可能涉及到不同的组件之间的传值，所以需要在切换之前进行一些处理
clearlist(e,t){this.WayLineActionList[t]=this.displayedComponents,this.WayLineActionList.hasOwnProperty(e)||(this.WayLineActionList[e]=[]),this.displayedComponents=this.WayLineActionList[e]},
//上面的清除list函数针对于顺序插入航点
//下面的函数针对于在某点前面插入一个点，也就是在中间插入，所以不仅需要清除面板中的组价消息
//还需要将列表中后续的所有组件顺序往后一位
clearlistforInsert(e){const t=L.state.wayLinePointsDrawing.length;if("before"===L.state.wayLinePointsDrawing[e].addManner){this.WayLineActionList[e]=this.displayedComponents;for(let a=t-2;a>=e;a--)this.WayLineActionList.hasOwnProperty(a)||(this.WayLineActionList[a]=[]),this.WayLineActionList[a+1]=this.WayLineActionList[a];this.WayLineActionList[e]=[],this.displayedComponents=this.WayLineActionList[e]}else{this.WayLineActionList[e-1]=this.displayedComponents;for(let a=t-1;a>=e;a--)this.WayLineActionList.hasOwnProperty(a)||(this.WayLineActionList[a]=[]),this.WayLineActionList[a+1]=this.WayLineActionList[a];this.WayLineActionList[e]=[],this.displayedComponents=this.WayLineActionList[e]}},
//这里是往左切换航点
increment(){this.WayLineActionList[this.selectedPoint.number]=this.displayedComponents,this.selectedPoint.number++,this.selectedPoint.number>L.state.wayLinePointsDrawing.length-1&&(this.selectedPoint.number=0),this.WayLineActionList.hasOwnProperty(this.selectedPoint.number)||(this.WayLineActionList[this.selectedPoint.number]=[]);const e={pointId:L.state.wayLinePointsDrawingActive.pointId,pointX:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointX,pointY:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointY,pointZ:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointZ};L.commit("SET_WAY_LINE_POINT_DRAWING_ACTIVE",e),this.displayedComponents=this.WayLineActionList[this.selectedPoint.number]},
//这里是往右切换航点
decrement(){this.WayLineActionList[this.selectedPoint.number]=this.displayedComponents,this.selectedPoint.number--,this.selectedPoint.number<0&&(this.selectedPoint.number=L.state.wayLinePointsDrawing.length-1),this.WayLineActionList.hasOwnProperty(this.selectedPoint.number)||(this.WayLineActionList[this.selectedPoint.number]=[]);const e={pointId:L.state.wayLinePointsDrawingActive.pointId,pointX:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointX,pointY:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointY,pointZ:L.state.wayLinePointsDrawing[this.selectedPoint.number].pointZ};L.commit("SET_WAY_LINE_POINT_DRAWING_ACTIVE",e),this.displayedComponents=this.WayLineActionList[this.selectedPoint.number]},toggleDropdown(){this.showDropdown=!this.showDropdown},setHoveredItem(e){this.hoveredItem=e},clearHoveredItem(){this.hoveredItem=null},showItemComponent(e){switch(e.componentName){case"StartRecord":case"StopRecord":case"StartEqualIntervalTakePhoto":case"StartEqualDistanceIntervalTakePhoto":case"StopEqualIntervalTakePhoto":case"Hover":case"DroneYaw":case"GimbalYaw":case"GimbalPitch":case"TakePhoto":case"Zoom":case"NewFolder":this.displayedComponents.push({id:e.id,componentName:e.componentName,ComponentIndex:this.displayedComponents.length})}this.showDropdown=!this.showDropdown},deleteItem(e){-1!==e&&(this.displayedComponents[e]={},this.HandleReturnValues(e,{}),this.StoreWayLineActionList[this.selectedPoint.number]=this.MyDelete(this.StoreWayLineActionList[this.selectedPoint.number]))},
//清除对象中值为{}的键值对
MyDelete(e){const t={...e};for(const a in t)if(Object.prototype.hasOwnProperty.call(t,a)){const e=t[a];"object"==typeof e&&0===Object.keys(e).length&&delete t[a]}return t},
//将子组件传回的参数存储起来
//暂时留下一个问题，需要在所有航点创建之后再新建航点动作
HandleReturnValues(e,t){if(null===this.selectedPoint.number)return;this.StoreWayLineActionList[this.selectedPoint.number]||(this.StoreWayLineActionList[this.selectedPoint.number]={}),this.StoreWayLineActionList[this.selectedPoint.number]["count"+e]=t;let a=[];Object.keys(this.StoreWayLineActionList).forEach((e=>{a.push({index:e,param:this.StoreWayLineActionList[e]})})),L.commit("SET_BEFORE_PROCESS_WAYLINE_ACTION",a)}}},[["render",function(e,t,o,s,r,m){return a(),n("div",me,[i("div",de,[i("div",{class:"BtnTrunLeft",onClick:t[0]||(t[0]=(...e)=>m.decrement&&m.decrement(...e))}),null===r.selectedPoint.number?(a(),n("div",ce,"航点")):(a(),n("div",ue,"航点 "+N(r.selectedPoint.number+1),1)),i("div",{class:"BtnTrunRight",onClick:t[1]||(t[1]=(...e)=>m.increment&&m.increment(...e))}),i("div",{class:"NewWayPointActionList",onClick:t[2]||(t[2]=(...e)=>m.toggleDropdown&&m.toggleDropdown(...e))}),P(i("div",he,[i("ul",null,[(a(!0),n(l,null,g(r.items,(e=>(a(),n("li",{key:e.id,onClick:t=>m.showItemComponent(e),onMouseover:t=>m.setHoveredItem(e),onMouseout:t[3]||(t[3]=(...e)=>m.clearHoveredItem&&m.clearHoveredItem(...e)),class:f({hovered:e===r.hoveredItem})},N(e.text),43,pe)))),128))])],512),[[I,r.showDropdown]])]),t[5]||(t[5]=i("br",null,null,-1)),i("div",we,[t[4]||(t[4]=i("div",{class:"ActionListTitle"},"已添加的航点动作：",-1)),i("div",ye,[(a(!0),n(l,null,g(r.displayedComponents,(e=>(a(),D(A(e.componentName),{key:e.id,fatherMsg:e.ComponentIndex,onDeleteItem:m.deleteItem,onHandleReturnValues:m.HandleReturnValues},null,40,["fatherMsg","onDeleteItem","onHandleReturnValues"])))),128))])])])}],["__scopeId","data-v-5342ca94"]]),Pe=Object.freeze(Object.defineProperty({__proto__:null,default:Ne},Symbol.toStringTag,{value:"Module"}));export{Z as A,Ne as a,Pe as b,v as s};
