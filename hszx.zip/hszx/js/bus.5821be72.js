import{aS as o}from"./.store.9749408e.js";const s=o();export{s as b};
