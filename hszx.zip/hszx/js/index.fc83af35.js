import{_ as r}from"./plugin-vue_export-helper.1b428a4d.js";import{j as e,s as o}from"./.store.08cd4578.js";const s=r({},[["render",function(r,s){return e(),o("div")}]]);export{s as default};
